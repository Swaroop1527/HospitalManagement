
addWindow("NewWindow",true,0,"","","","","NewWindow",2,2,"toc|ndx|nls|gls","toc");



putCshData(gsProjPath,gaCsh,gaWindow,gaRmtProj);
