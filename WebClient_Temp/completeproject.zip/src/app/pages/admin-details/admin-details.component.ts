import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-details',
  templateUrl: './admin-details.component.html',
  styleUrl: './admin-details.component.less'
})
export class AdminDetailsComponent {
  showHeadOfficeData: boolean = false;
  showBranchOfficeData:boolean = false;
  showDoctorOfficeData:boolean = false;
  showPatientOfficeData:boolean = false;


  showHeadOffice() {
    this.showHeadOfficeData = true;
    this.showBranchOfficeData = false;          
    this.showDoctorOfficeData = false;       
    this.showPatientOfficeData= false;
  }
  
  showBranchOffice() {
    this.showBranchOfficeData = true;
    this.showHeadOfficeData = false;
    this.showDoctorOfficeData = false;
    this.showPatientOfficeData = false

  }
  
  showDoctorDetails() {
    this.showDoctorOfficeData = true;
    this.showHeadOfficeData = false;
    this.showBranchOfficeData = false;
    this.showPatientOfficeData = false


  }
  
  showPatientDetails() {
    this.showPatientOfficeData = true;
    this.showHeadOfficeData = false;
    this.showBranchOfficeData = false;
    this.showDoctorOfficeData = false
  }




}
