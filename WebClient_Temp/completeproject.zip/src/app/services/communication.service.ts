import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { environment } from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class CommunicationService {

  constructor(private _http: HttpClient) {}
  
  public getHeadOfficeData(){
    return this._http.get('assets/headoffice.json')
};

public getBrachOfficeData(){
  return this._http.get('assets/branch.json')
};

public getDoctorDetails(){
  return this._http.get('assets/doctor.json')
}

public getPatientData(){
  return this._http.get('assets/patient.json')
}

  public getVersion(){
    return this._http.get(`${environment.baseUrl}/serverversion`)
  }




}