import { Component } from '@angular/core';

@Component({
  selector: 'app-head-office-details',
  templateUrl: './head-office-details.component.html',
  styleUrl: './head-office-details.component.less'
})
export class HeadOfficeDetailsComponent {

}
